from django.contrib import admin
from .models import Category, Product

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('categoryID', 'name', 'created_at')
    search_fields = ('categoryID', 'name')

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('sku', 'name', 'sale_price', 'digital', 'shipping_cost', 'category')
    search_fields = ('sku', 'name', 'category__name')
    list_filter = ('digital', 'category')

