from django.urls import path
from .views import CategoryList, ProductList

urlpatterns = [
    path('K_shop/categories/', CategoryList.as_view(), name='category-list'),
    path('K_shop/products/', ProductList.as_view(), name='product-list'),
]
