from django.db import models

class Category(models.Model):
    categoryID = models.CharField(max_length=50, unique=True,primary_key=True,default='')
    name = models.CharField(max_length=50)
    


    def __str__(self):
        return self.name

class Product(models.Model):
    sku = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=255)
    sale_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    images = models.JSONField(default=list)
    digital = models.BooleanField(default=False)
    shipping_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    description = models.TextField(null=True, default=None)
    customer_review_count = models.IntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)


    def __str__(self):
        return self.name
