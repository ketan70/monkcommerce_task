from django.apps import AppConfig


class CatalogSyncConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Catalog_sync'
