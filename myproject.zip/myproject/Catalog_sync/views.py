import requests 
from django.http import JsonResponse
from django.shortcuts import render

from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST
from .models import Category, Product


def categories(request):
    url = "https://stageapi.monkcommerce.app/task/categories"
    headers = {"x-api-key": "72njgfa948d9aS7gs5"}  # replace with your API key
    
    response = requests.get(url, headers=headers)

    data = response.json()

    print(data)
    
    categories = data.get("categories", [])
    for category_data in categories:
        category_id = category_data.get("id")
        name = category_data.get("name")
        
        category, _ = Category.objects.get_or_create(
            category_id=category_id,
            defaults={"name": name},
            )
        category.save()
    
    return JsonResponse({"success": True})




################################################################################!!!!@@@@@@@@@222



def product(request):
    # category_id = "abcat0010000"
    # if not category_id:
    #     return JsonResponse({"error": "Missing categoryID parameter"}, status=400)
    
    url = "https://stageapi.monkcommerce.app/task/products"
    headers = {"x-api-key": "72njgfa948d9aS7gs5"}  
    
    page = 1

    # params = {"limit": 100, "page": page, "categoryID": category_id}

    response = requests.get(url, headers=headers)
    data = response.json()

    print(data)

    products = data.get("products", [])
    
    if products :

        for product_data in products:

            sku = product_data.get("sku")
            name = product_data.get("name")
            sale_price = product_data.get("sale_price")
            images = product_data.get("images")
            digital = product_data.get("digital")
            shipping_cost = product_data.get("shipping_cost")
            description =product_data.get("description")
            customer_review_count = product_data.get("customer_review_count")
            category = product_data.get("category")
            
            product, _ = Product.objects.get_or_create(
                sku = sku,
                defaults={
                    "name" : name,
                    "sale_price" : sale_price,
                    "images" : images,
                    "digital" : digital,
                    "shipping_cost" : shipping_cost,
                    "description" : description,
                    "customer_review_count" : customer_review_count,
                    "category" : category,
                }
            )
            product.save()
        
    return JsonResponse({"success": True})

def home(request):
    products = Product.objects.all()
    return render(request, 'Home.html', {'products': products})
