from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Category, Product
from .serializers import CategorySerializer, ProductSerializer
from django.db.models import Count

class CategoryList(APIView):
    def get(self, request, format=None):
        limit = request.query_params.get('limit')
        page = request.query_params.get('page')
        categories = Category.objects.annotate(num_products= Count('product')).order_by('-num_products')
        if limit:
            categories = categories[:limit]
        if page:
            categories = categories[(page-1)*limit:page*limit]
        serializer = CategorySerializer(categories, many=True)
        return Response({'page': page, 'categories': serializer.data}, status=status.HTTP_200_OK)

class ProductList(APIView):
    def get(self, request, format=None):
        limit = request.query_params.get('limit')
        page = request.query_params.get('page')
        categoryID = 1
        products = Product.objects.filter(category=categoryID).order_by('-customer_review_count')
        if limit:
            products = products[:limit]
        if page:
            products = products[(page-1)*limit:page*limit]
        serializer = ProductSerializer(products, many=True)
        return Response({'page': page, 'products': serializer.data}, status=status.HTTP_200_OK)
